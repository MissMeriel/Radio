package v3;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

public class RadioStationGUI extends JFrame {
	private JTabbedPane tp;
	private JPanel playlistMakerTab, finalizedPlaylistsTab,
			finalizedPlaylistsPanel;
	private PlaylistMakerPanel playlistMakerPanel;
	private SongInputPanel songInputPanel;
	protected Playlist playlist = new Playlist("");
	protected NewSongs newSongs = new NewSongs();
	protected OldSongs oldSongs = new OldSongs();
	boolean testing = true;
	protected RDSPanel rdsPanel;

	public RadioStationGUI() {

		// setup Jframe
		super("WACM DJ Set Playlist");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setMinimumSize(new Dimension(400, 600));
		//setPreferredSize(new Dimension(500, 600));

		// update newSongs and oldSongs
		updateSongs();

		// native method constructs tabbed pane
		makeTabbedPane();
	}

	private void makeTabbedPane() {
		tp = new JTabbedPane();
		playlistMakerTab = new JPanel();
		playlistMakerTab.setLayout(new BorderLayout());
		finalizedPlaylistsTab = new FinalizedPlaylistPanel();
		rdsPanel = new RDSPanel();
		
		// Add this panel that has our songInputPanel to our big panel.
		// songInputPanel will occupy the left cell.
		songInputPanel = new SongInputPanel(playlist, newSongs, oldSongs);
		
		// Add right panel to second cell in GridLayout.
		playlistMakerPanel = new PlaylistMakerPanel(playlist, rdsPanel);
		playlistMakerTab.add(playlistMakerPanel, BorderLayout.EAST);
		playlistMakerTab.add(songInputPanel, BorderLayout.WEST);
		JPanel rdsPnl = new JPanel(new FlowLayout());
		rdsPnl.add(rdsPanel);
		playlistMakerTab.add(rdsPnl, BorderLayout.SOUTH);
		finalizedPlaylistsPanel = new FinalizedPlaylistPanel();
		finalizedPlaylistsTab.add(finalizedPlaylistsPanel);

		tp.addTab("Playlist Maker", playlistMakerTab);
		tp.addTab("Finalized Playlists", finalizedPlaylistsTab);

		
		// Need to add that SSListener to the pMP, or else we can't do what we
		// wrote
		playlistMakerPanel.playlistList
				.addListSelectionListener(new SongSelectionListener());
		songInputPanel.newSongList
				.addListSelectionListener(new SongSelectionListener());
		songInputPanel.oldSongList
				.addListSelectionListener(new SongSelectionListener());

		add(tp);
		pack();
		setVisible(true);
	}

	/**
	 * populate NewSongs (the hot list) and update when a week has passed
	 */
	public void updateSongs() {
		if (testing)
			System.out.println("updateNewSongs()");
		if (newSongs.getLastUpdated() != null) {

			if (LocalDate.now().minusWeeks(1)
					.compareTo(newSongs.getLastUpdated()) < 0) {
				oldSongs.add(newSongs.update());
			}
		} else {
			oldSongs.update();
			oldSongs.add(newSongs.update());
		}
	} // end updateSongs()

	// reports will be bundled in the gui; it's a functionality of the playlist
	// but it would
	// have to either be passed an array of Reports to add
	public void generateAds() throws FileNotFoundException {
		Reader rdr = new Reader("src/AdList.txt");
		ArrayList<Commercial> adList = rdr.getCommercials();
		Random rand = new Random();
		rand.nextInt(adList.size());
	}

	/**
	 * inserts a 5-minute block of ads every 30 minutes
	 */
	// private final Duration AUTO_INSERT_INTERVAL =
	// Duration.ofSeconds((25*60)l);
//	public void insertAds() {
//		if(playlist.getLength())
//	}
//
//	public void generateReports() throws FileNotFoundException {
//
//	}
//
//	/**
//	 * inserts a 2-minute block of reports every 60 minutes
//	 */
//	public void insertReports() {
//		if(playlist.getLength().minus(Duration.ofHours(playlist.getLength().toHours())).compareTo(Playlist.TIME_REMAINING_EPSILON) )
//	}

	
	
	private class SongSelectionListener implements ListSelectionListener {

		@Override
		public void valueChanged(ListSelectionEvent e) {
			Song current = (Song) ((JList) e.getSource()).getSelectedValue();
			System.out.println(current);
			if (!e.getValueIsAdjusting()) {

				if (testing)
					System.out.print("Mouse pressed, ");

				// if event source is the playlist
				// NEEDS to be playlistList, NOT playlistListModel
				if (e.getSource().equals(playlistMakerPanel.playlistList)
						&& playlist.getSongs().size() > 0
						&& playlistMakerPanel.playlistList.getSelectedIndex() > -1) {
					System.out.println("playlistMakerPanel");
					int index = playlistMakerPanel.playlistList
							.getSelectedIndex();

					try {
						System.out.println("selected index: " + index);
						playlist.deleteSong(index);
						playlistMakerPanel.playlistListModel.remove(index);
						playlistMakerPanel.playlistList.clearSelection();

						// This is what "repaints" the JList
						playlistMakerPanel.playlistList.setListData(playlist
								.getSongs().toArray());

						int size = playlistMakerPanel.playlistListModel
								.getSize();
						System.out.println("playlistListModel size: " + size);

					} catch (IndexOutOfBoundsException excep) {
						playlistMakerPanel.playlistList.setListData(playlist
								.getSongs().toArray());
					}
					
					rdsPanel.getMarqueePanel().setMarqueeText(current.toString());
				}

				// if event source is the JList newSongs
				if (e.getSource().equals(songInputPanel.newSongList)) {
					System.out.println("newSongs");
					// add selected song to playlist
					playlist.addSong(current);
					playlistMakerPanel.playlistList.setListData(playlist
							.getSongs().toArray());
					System.out.println(playlistMakerPanel.playlistList
							.getModel().getSize());
				}

				// if event source is the JList oldSongs
				if (e.getSource().equals(songInputPanel.getOldSongsList())) {
					System.out.println("oldSongs");

					// add selected song to playlist
					playlist.addSong(current);
					playlistMakerPanel.playlistList.setListData(playlist
							.getSongs().toArray());
					System.out.println("playlistListModel size: "
							+ playlistMakerPanel.playlistList.getModel()
									.getSize());
				}
				try {
					playlistMakerPanel.updateTimeRemaining(playlist
							.timeRemaining());
				} catch (OverTimeException e1) {
				}
			}
		} // end valueChanged()
	}// end SongSelectionListener

}
