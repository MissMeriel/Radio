package v3;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;

/**
 *  Program which scrolls desired text in a JTextField.
 *
 */
public class MarqueePanel extends JPanel{
	protected static Timer marqueeTimer;
	private String marqueeText;
	private JTextField textOutput = new JTextField();

	
	/**
	 *  Constructor for the Marquee object
	 *
	 *  @param  marquee  String passed is the desired marquee message.
	 */
	public MarqueePanel(String marquee) {
		textOutput.setEditable(false);
		setPreferredSize(new Dimension(200, 100));
		marqueeText = marquee;
		marqueeTimer = new Timer(200,
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					marqueeText = marqueeText.substring(1, marqueeText.length()) + marqueeText.charAt(0);
					textOutput.setText(marqueeText);
				}
			} );
		add(textOutput);
		marqueeTimer.start();
		textOutput.setVisible(true);
		
	}

	/**
	 *  Class extends toString.
	 *
	 *  @return    Returns a string format of the marquee object.
	 */
	public String toString() {
		return marqueeText;
	}
	
	/**
	 * Sets the text of the marquee
	 * @param text
	 */
	public void setMarqueeText(String text) {
		setVisible(false);
		System.out.println("inside setMarqueeText");
		marqueeText = text;
		//remove(textOutput);
		textOutput.setText(marqueeText);
		//add(textOutput);
		//textOutput.setVisible(true);
		System.out.println(textOutput.getText());
		System.out.println("GetParent() is null: " +(getParent() == null));
		//getParent().setVisible(true);
		
//		revalidate();
//		repaint();
	}
	
	public void stop() {
		marqueeTimer.stop();
	}
	
	public void start() {
		marqueeTimer.start();
	}
}

