package v3;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class RDSPanel extends JPanel {

	private DefaultListModel dlm = new DefaultListModel();
	private JComboBox playlistBox;
	private MarqueePanel marqueePanel = new MarqueePanel("RDS emulation here");
	private JPanel rightPanel;

	public RDSPanel() {

		setLayout(new BorderLayout());
		//setPreferredSize(new Dimension(100, 400));
		
		// Maybe make another panel class for this??
		rightPanel = new JPanel();
		MarqueePanel marqueePanel = new MarqueePanel("Does it work? ");
		add(marqueePanel, BorderLayout.SOUTH);
		rightPanel.add(marqueePanel);
		add(rightPanel, BorderLayout.SOUTH);
	}
	
	public MarqueePanel getMarqueePanel(){
		return marqueePanel;
	}

}
