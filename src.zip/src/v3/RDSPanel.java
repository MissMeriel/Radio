package v3;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class RDSPanel extends JPanel {
	// I used some playlist data from new songs just to test my code
	private Playlist playlist1 = new Playlist("first");
	private Playlist playlist2 = new Playlist("second");
	private Playlist[] playlists = new Playlist[2];
	private ArrayList<Song> songs1;
	private ArrayList<Song> songs2;

	private JScrollPane songPane;
	private JList songList;
	private DefaultListModel dlm = new DefaultListModel();
	private JComboBox playlistBox;
	private MarqueePanel marqueePanel = new MarqueePanel("Does it work? ");
	private JPanel rightPanel;

	public RDSPanel() {

		setLayout(new BorderLayout());

		// This stuff is just for testing code with stock playlists.
		try {
			Reader reader1 = new Reader("src/NewSongs1.txt");
			songs1 = reader1.getSongs();
			Reader reader2 = new Reader("src/NewSongs2.txt");
			songs2 = reader2.getSongs();
		} catch (FileNotFoundException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Song song : songs1) {
			playlist1.addSong(song);
		}

		for (Song song : songs2) {
			playlist2.addSong(song);
		}

		playlists[0] = playlist1;
		playlists[1] = playlist2;
		// ^ Normally we'd want to get playlist data from a collection of
		// finished playlists of some kind.

		// Create combo box, set its index upon start to be -1 (so it's blank)
		// Add new ComboListener
		playlistBox = new JComboBox(playlists);
		playlistBox.setSelectedIndex(-1);
		playlistBox.addActionListener(new ComboListener());

		// Set up the JList and put into a JScrollPane
		songList = new JList(dlm);
		songList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		songList.addListSelectionListener(new JListListener());
		songPane = new JScrollPane(songList);
		songPane.setPreferredSize(new Dimension(150, 350));

		// Create a panel for our combo box and JList using vertical box layout
		JPanel playlistSelector = new JPanel();
		playlistSelector.setLayout(new BoxLayout(playlistSelector, BoxLayout.Y_AXIS));

		// Add combo box and scroll pane into container panel that has vertical
		// box layout.
		playlistSelector.add(playlistBox);
		playlistSelector.add(songPane);
		// Add this container panel to the tab.
		add(playlistSelector, BorderLayout.CENTER);

		// Maybe make another panel class for this??
		rightPanel = new JPanel();
		MarqueePanel marqueePanel = new MarqueePanel("Does it work? ");
		add(marqueePanel, BorderLayout.SOUTH);
		rightPanel.add(marqueePanel);
		add(rightPanel, BorderLayout.SOUTH);
	}

	// Listener for combo box to display the songs in a particular playlist in
	// the JList.
	private class ComboListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// Clears the JList
			setVisible(false);
			songList.clearSelection();
			
			// Gets the selected Playlist from JComboBox
			Playlist p = (Playlist) playlistBox.getSelectedItem();
			
			// Clears out defaultlistmodel and adds relevant songs
			dlm.clear();
			for (Song song : p.getSongs()) {
				dlm.addElement(song);
			}

			
			songList.setSelectedIndex(0);
			
			// Set the new marquee to first one in the list.
			String marqueeText = songList.getSelectedValue().toString();
			marqueePanel.setMarqueeText(marqueeText);
		} // end actionPerformed()
	} // end ComboListener

	// Can't make the RDS display show up without having to resize window or click
	private class JListListener implements ListSelectionListener {
		@Override
		public void valueChanged(ListSelectionEvent e) {
			if (!e.getValueIsAdjusting()) {
				
				// Song that user selects saved to variable
				Song currentSong = (Song) songList.getSelectedValue();
				try {
					marqueePanel = (MarqueePanel) rightPanel.getComponent(0);
					marqueePanel.setMarqueeText(currentSong.displayRDS());
				} catch (NullPointerException exc) {
				}

			}
		}
	}

}
