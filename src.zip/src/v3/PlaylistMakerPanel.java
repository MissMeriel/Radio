package v3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PlaylistMakerPanel extends JPanel {

	JLabel playlistTitle = new JLabel("");;
	JButton playlistTitleEdit = new JButton("Enter");
	JTextField playlistTitler = new JTextField("Your Playlist Title");
	JLabel timeRemaining = new JLabel("Time Remaining: 4:00:00");
	JPanel topPanel = new JPanel(new GridLayout(2, 1));
	JPanel mid, midPanel, bot, botPanel;
	public DefaultListModel playlistListModel;
	public JList playlistList = new JList();
	public JScrollPane playlistPane;
	public Playlist playlist;
	boolean testing = true;

	public PlaylistMakerPanel(Playlist playlist) {
		this.playlist = playlist;
		// Now we need to set up the right side of the playlistMakerPanel.
		// Using BorderLayout so creating panels to put in North/Central/South
		setLayout(new BorderLayout());

		// topPanel holds playlist title and timeRemaining
		makeTitlePanel();

		// mid panel displays the playlist we're working on.
		//if (playlist.getSongs().size() > 0)
		// playlist.getSongs().forEach(e -> playlistListModel.addElement(e));
		// playlistPane.add(playlistList);
		playlistListModel = new DefaultListModel();
		if (playlist.getSongs().size() > 0) {
			for (Song song : playlist.getSongs()) {
				playlistListModel.addElement(song);

			}
		}
		playlistList = new JList(playlistListModel);
		playlistList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		playlistList.setCellRenderer(new PlaylistCellRenderer());
		playlistList.addListSelectionListener(new PlaylistSelectionListener());
		playlistPane = new JScrollPane(playlistList);
		playlistPane.setOpaque(true);
		playlistPane.setPreferredSize(new Dimension(200, 350));
		mid = new JPanel();
		mid.add(playlistPane);

		// Create our buttons. Need listeners!
		JButton rdsButton = new JButton("View in RDS");
		JButton finalizeButton = new JButton("Finalize");
		bot = new JPanel();
		bot.add(rdsButton);
		bot.add(finalizeButton);

		// Add the panels to their respective places.
		add(topPanel, BorderLayout.NORTH);
		add(mid, BorderLayout.CENTER);
		add(bot, BorderLayout.SOUTH);
	}

	public void updateTimeRemaining(String str){
		timeRemaining.setText(str);
	}
	public JList getList() {
		return playlistList;
	}

	// top holds playlist title and editing button
	private void makeTitlePanel() {

		JPanel top = new JPanel();

		// grid layout of 2 rows and 1 column
		top.setLayout(new GridLayout(1, 2));

		playlistTitler.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {
				playlistTitler.setText("");
			}

			@Override
			public void focusLost(FocusEvent e) {
				// playlistTitler.setText("Your Playlist Title");
			}
		});

		// when edit/enter button clicked, playlist title is entered/edited
		playlistTitleEdit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// if the title is editable
				if (playlistTitleEdit.getText().equals("Enter")) {
					playlistTitle.setText(playlistTitler.getText());
					playlistTitleEdit.setText("Edit");
					// top.remove(playlistTitler);
					top.removeAll();
					top.add(playlistTitle);
					top.add(playlistTitleEdit);
					playlist.setPlaylistName(playlistTitle.getText());

					// if the user wants to edit the title
				} else {
					top.removeAll();
					top.add(playlistTitler);
					playlistTitleEdit.setText("Enter");
					top.add(playlistTitleEdit);
				}

			}
		});
		top.add(playlistTitler);
		top.add(playlistTitleEdit);
		// playlistTitleEdit.setAlignmentY(RIGHT_ALIGNMENT);
		topPanel.add(top);
		topPanel.add(timeRemaining);

	}
	
	public class PlaylistSelectionListener implements ListSelectionListener {

		@Override
		public void valueChanged(ListSelectionEvent e) {
			int size = playlistListModel.getSize();
			int index = playlistList.getSelectedIndex();
			if (!e.getValueIsAdjusting() && playlist.getSongs().size() > 0
					&& index > -1) {
				if (testing)
					System.out.print("Playlist event, selected index: " + index);

				// remove song from playlist and jlist - right now only
				// removes when you add another song
				try {
					
					// remove song from playlist
					playlist.deleteSong(((JList) e.getSource()).getSelectedIndex());
					((JList) e.getSource()).clearSelection();
					
					System.out.println("selection empty? "+((JList) e.getSource()).isSelectionEmpty());
					((JList) e.getSource()).setVisible(true);//repaint();
					//update(getGraphics());
					
					
					System.out.println("playlistListModel size: " + playlistListModel.getSize());
				} catch (IndexOutOfBoundsException excep) {
					playlistPane.revalidate();
					playlistPane.repaint();
				}
				
			} // end getValueIsAdjusting
		} // end valueChanged
	}// end PlaylistSelectionListener
	
	private class PlaylistCellRenderer extends DefaultListCellRenderer {
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			Component comp = super.getListCellRendererComponent(list, value, index,
					false, false);

			if (isSelected && cellHasFocus) {

				comp.setForeground(Color.gray);
				comp.setEnabled(false);
			}
			return comp;
		} 
	} // end PlaylistCellRendererComponent
	
} // end PlaylistMakerPanel


