package v3;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.*;

public class FinalizedPlaylistPanel extends JPanel {

	public FinalizedPlaylistPanel() {
		// The second tab!
		// finalizedPlaylistsTab.setLayout(new GridLayout());
		setLayout(new GridLayout());
		addFinalizedPanels();

	}

	/**
	 * Display each playlist we have saved using a new JScrollPane for each
	 * playlist we have in some collection
	 */
	private void addFinalizedPanels() {

		// Test loop:
		// loop doesn't add two of them? I guess because it uses same panels?
		for (int i = 0; i < 2; i++) {
			JPanel finalizedPanel = new JPanel();
			finalizedPanel.setLayout(new BoxLayout(finalizedPanel,
					BoxLayout.Y_AXIS));
			JLabel listLabel = new JLabel("Playlist Title");
			JScrollPane playlistScroller = new JScrollPane();
			playlistScroller.setPreferredSize(new Dimension(10, 400));
			finalizedPanel.add(listLabel);
			finalizedPanel.add(playlistScroller); // needs to have playlist to
													// scroll through
			add(finalizedPanel);
			i++;
		}
	}

}
