package v3;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

public class RadioStationGUI extends JFrame {
	private JTabbedPane tp;
	private JPanel playlistMakerTab, finalizedPlaylistsTab,
			finalizedPlaylistsPanel;
	private PlaylistMakerPanel playlistMakerPanel;
	private SongInputPanel songInputPanel;
	protected Playlist playlist = new Playlist("");
	protected NewSongs newSongs = new NewSongs();
	protected OldSongs oldSongs = new OldSongs();
	boolean testing = true;

	public RadioStationGUI() {

		// setup Jframe
		super("WACM DJ Set Playlist");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setMinimumSize(new Dimension(400, 400));

		// update newSongs and oldSongs
		updateSongs();

		// native method constructs tabbed pane
		makeTabbedPane();
	}

	private void makeTabbedPane() {
		tp = new JTabbedPane();
		playlistMakerTab = new JPanel();
		playlistMakerTab.setLayout(new GridLayout(1, 2));
		finalizedPlaylistsTab = new FinalizedPlaylistPanel();
		tp.addTab("Playlist Maker", playlistMakerTab);
		tp.addTab("Finalized Playlists", finalizedPlaylistsTab);
		// Add this panel that has our songInputPanel to our big panel.
		// songInputPanel will occupy the left cell.
		songInputPanel = new SongInputPanel(playlist, newSongs, oldSongs);
		playlistMakerTab.add(songInputPanel);
		// Add right panel to second cell in GridLayout.
		playlistMakerPanel = new PlaylistMakerPanel(playlist);
		playlistMakerTab.add(playlistMakerPanel);
		finalizedPlaylistsPanel = new FinalizedPlaylistPanel();
		finalizedPlaylistsTab.add(finalizedPlaylistsPanel);

		// Need to add that SSListener to the pMP, or else we can't do what we
		// wrote
		playlistMakerPanel.playlistList
				.addListSelectionListener(new SongSelectionListener());
		songInputPanel.newSongList
				.addListSelectionListener(new SongSelectionListener());
		songInputPanel.oldSongList
				.addListSelectionListener(new SongSelectionListener());

		add(tp);
		pack();
		setVisible(true);
	}

	/**
	 * populate NewSongs (the hot list) and update when a week has passed
	 */
	public void updateSongs() {
		if (testing)
			System.out.println("updateNewSongs()");
		if (newSongs.getLastUpdated() != null) {

			if (LocalDate.now().minusWeeks(1)
					.compareTo(newSongs.getLastUpdated()) < 0) {
				oldSongs.add(newSongs.update());
			}
		} else {
			// oldSongs.add(oldSongs.update());
			oldSongs.update();
			oldSongs.add(newSongs.update());
			// if (testing)
			// System.out.println("oldSongs after update(): "
			// + oldSongs.getSongs().size());
			// oldSongs.add(newSongs.update());
		}
	} // end updateSongs()

	// reports will be bundled in the gui; it's a functionality of the playlist
	// but it would
	// have to either be passed an array of Reports to add
	public void generateAds() throws FileNotFoundException {
		Reader rdr = new Reader("src/AdList.txt");
		ArrayList<Commercial> adList = rdr.getCommercials();
		Random rand = new Random();
		rand.nextInt(adList.size());
	}

	/**
	 * inserts a 5-minute block of ads every 25 minutes
	 */
	// private final Duration AUTO_INSERT_INTERVAL =
	// Duration.ofSeconds((25*60)l);
	public void insertAds() {

	}

	public void generateReports() throws FileNotFoundException {

	}

	/**
	 * inserts a 2-minute block of reports every 58 minutes
	 */
	public void insertReports() {

	}

	private class SongSelectionListener implements ListSelectionListener {

		@Override
		public void valueChanged(ListSelectionEvent e) {
			Song current = (Song) ((JList) e.getSource()).getSelectedValue();
			System.out.println(current);
			if (!e.getValueIsAdjusting()) {

				if (testing)
					System.out.print("Mouse pressed, ");

				// if event source is the playlist
				// NEEDS to be playlistList, NOT playlistListModel
				if (e.getSource().equals(playlistMakerPanel.playlistList)
						&& playlist.getSongs().size() > 0
						&& playlistMakerPanel.playlistList.getSelectedIndex() > -1) {
					System.out.println("playlistMakerPanel");
					int index = playlistMakerPanel.playlistList
							.getSelectedIndex();

					try {
						System.out.println("selected index: " + index);
						playlist.deleteSong(index);
						playlistMakerPanel.playlistListModel.remove(index);
						playlistMakerPanel.playlistList.clearSelection();

						// This is what "repaints" the JList
						playlistMakerPanel.playlistList.setListData(playlist
								.getSongs().toArray());

						int size = playlistMakerPanel.playlistListModel
								.getSize();
						System.out.println("playlistListModel size: " + size);

					} catch (IndexOutOfBoundsException excep) {
						playlistMakerPanel.playlistList.setListData(playlist
								.getSongs().toArray());
					}
				}

				// if event source is the JList newSongs
				if (e.getSource().equals(songInputPanel.newSongList)) {
					System.out.println("newSongs");
					// add selected song to playlist
					playlist.addSong(current);
					playlistMakerPanel.playlistList.setListData(playlist
							.getSongs().toArray());
					System.out.println(playlistMakerPanel.playlistList
							.getModel().getSize());
				}

				// if event source is the JList oldSongs
				if (e.getSource().equals(songInputPanel.getOldSongsList())) {
					System.out.println("oldSongs");

					// add selected song to playlist
					playlist.addSong(current);
					playlistMakerPanel.playlistList.setListData(playlist
							.getSongs().toArray());
					System.out.println("playlistListModel size: "
							+ playlistMakerPanel.playlistList.getModel()
									.getSize());
				}
				try {
					playlistMakerPanel.updateTimeRemaining(playlist
							.timeRemaining());
				} catch (OverTimeException e1) {
				}
			}
		} // end valueChanged()
	}// end SongSelectionListener
}
