package v3;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

public class RadioStationGUI extends JFrame {
	private JTabbedPane tp;
	private JPanel playlistMakerTab, finalizedPlaylistsTab,
			finalizedPlaylistsPanel;
	private PlaylistMakerPanel playlistMakerPanel;
	private SongInputPanel songInputPanel;
	protected Playlist playlist = new Playlist("");
	protected NewSongs newSongs = new NewSongs();
	protected OldSongs oldSongs = new OldSongs();
	boolean testing = true;

	public RadioStationGUI() {

		// setup Jframe
		super("WACM DJ Set Playlist");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setMinimumSize(new Dimension(400, 400));

		// update newSongs and oldSongs
		updateSongs();

		// native method constructs tabbed pane
		makeTabbedPane();
	}

	private void makeTabbedPane() {
		tp = new JTabbedPane();
		playlistMakerTab = new JPanel();
		playlistMakerTab.setLayout(new GridLayout(1, 2));
		finalizedPlaylistsTab = new FinalizedPlaylistPanel();
		tp.addTab("Playlist Maker", playlistMakerTab);
		tp.addTab("Finalized Playlists", finalizedPlaylistsTab);
		// Add this panel that has our songInputPanel to our big panel.
		// songInputPanel will occupy the left cell.
		songInputPanel = new SongInputPanel(playlist, newSongs, oldSongs);
		playlistMakerTab.add(songInputPanel);
		// Add right panel to second cell in GridLayout.
		playlistMakerPanel = new PlaylistMakerPanel(playlist);
		playlistMakerTab.add(playlistMakerPanel);
		finalizedPlaylistsPanel = new FinalizedPlaylistPanel();
		finalizedPlaylistsTab.add(finalizedPlaylistsPanel);

		songInputPanel.newSongList
				.addListSelectionListener(new SongSelectionListener());
		songInputPanel.oldSongList
				.addListSelectionListener(new SongSelectionListener());
//		playlistMakerPanel.getList()
//				.addListSelectionListener(new PlaylistSelectionListener());
		add(tp);
		pack();
		setVisible(true);
	}

	/**
	 * populate NewSongs (the hot list) and update when a week has passed
	 */
	public void updateSongs() {
		if (testing)
			System.out.println("updateNewSongs()");
		if (newSongs.getLastUpdated() != null) {

			if (LocalDate.now().minusWeeks(1)
					.compareTo(newSongs.getLastUpdated()) < 0) {
				oldSongs.add(newSongs.update());
			}
		} else {
			// oldSongs.add(oldSongs.update());
			oldSongs.update();
			oldSongs.add(newSongs.update());
			// if (testing)
			// System.out.println("oldSongs after update(): "
			// + oldSongs.getSongs().size());
			// oldSongs.add(newSongs.update());
		}
	} // end updateSongs()
	
	// reports will be bundled in the gui; it's a functionality of the playlist
	// but it would
	// have to either be passed an array of Reports to add
	public void generateAds() throws FileNotFoundException {
		Reader rdr = new Reader("src/AdList.txt");
		ArrayList<Commercial> adList = rdr.getCommercials();
		Random rand = new Random();
		rand.nextInt(adList.size());
	}

	/**
	 * inserts a 5-minute block of ads every 25 minutes
	 */
	// private final Duration AUTO_INSERT_INTERVAL =
	// Duration.ofSeconds((25*60)l);
	public void insertAds() {

	}

	public void generateReports() throws FileNotFoundException {

	}

	/**
	 * inserts a 2-minute block of reports every 58 minutes
	 */
	public void insertReports() {

	}

	private class SongSelectionListener implements ListSelectionListener {

		@Override
		public void valueChanged(ListSelectionEvent e) {
			Song current = (Song) ((JList) e.getSource()).getSelectedValue();
			if (!e.getValueIsAdjusting()) {
				if (testing)
					System.out.print("Mouse pressed, ");

				// if event source is the playlist
				if (e.getSource().equals(playlistMakerPanel.playlistListModel)
						&& playlist.getSongs().size() > 0
						&& playlistMakerPanel.playlistList.getSelectedIndex() > -1) {
					System.out.println("playlistMakerPanel");
					int index = playlistMakerPanel.playlistList
							.getSelectedIndex();

					// remove song from playlist and jlist - right now only
					// removes when you add another song
					try {
						System.out.println("selected index: " + index);
						playlist.deleteSong(index);
						playlistMakerPanel.playlistListModel.remove(index);
						playlistMakerPanel.playlistList.clearSelection();
						// update GUI to reflect changes
						// playlistMakerPanel.playlistList.removeAll();
						// playlistMakerPanel.playlistList = new
						// JList(playlistMakerPanel.playlistListModel);
						setVisible(true);
						playlistMakerPanel.playlistList.revalidate();
						playlistMakerPanel.playlistList.repaint();

						int size = playlistMakerPanel.playlistListModel
								.getSize();
						System.out.println("playlistListModel size: " + size);
					} catch (ArrayIndexOutOfBoundsException excep) {
					}

					// return song to oldSongsList if it was from OldSongs
					// if (oldSongs.contains(current)) {
					// // Song song = ((Song)
					// System.out.println(songInputPanel.getOldSongsList()
					// .getComponents());
					// int index1 = oldSongs.getIndexOf(current);
					// playlistMakerPanel.playlistListModel
				}

				// playlistMakerPanel.playlistPane.
				revalidate();
				// playlistMakerPanel.playlistPane.
				repaint();

				// if event source is the JList newSongs
				if (e.getSource().equals(songInputPanel.newSongList)) {
					System.out.println("newSongs");
					// add selected song to playlist
					playlist.addSong(current);
					// System.out.println("playlist size: "
					// + playlist.getSongs().size());
					// System.out.println(playlist);
					playlistMakerPanel.playlistList.setListData(playlist
							.getSongs().toArray());
					// System.out.println(playlistMakerPanel.playlistList.getModel().equals(playlist
					// .getSongs().toArray()));
					System.out.println(playlistMakerPanel.playlistList
							.getModel().getSize());
					playlistMakerPanel.// playlistPane.
							revalidate();
					playlistMakerPanel.// playlistPane.
							repaint();
				}

				// if event source is the JList oldSongs
				if (e.getSource().equals(songInputPanel.getOldSongsList())) {
					System.out.println("oldSongs");

					// add selected song to playlist
					playlist.addSong(current);
					playlistMakerPanel.playlistList.setListData(playlist
							.getSongs().toArray());
					System.out.println("playlistListModel size: "
							+ playlistMakerPanel.playlistList.getModel()
									.getSize());
					// playlistMakerPanel.playlistPane.
					revalidate();
					// playlistMakerPanel.playlistPane.
					repaint();
					try {
						playlistMakerPanel.updateTimeRemaining(playlist.timeRemaining());
					} catch (OverTimeException e1) {
					}
				}
			}
		} // end valueChanged()
	}// end SongSelectionListener

//	public class PlaylistSelectionListener implements ListSelectionListener {
//
//		@Override
//		public void valueChanged(ListSelectionEvent e) {
//			JList jl = playlistMakerPanel.getList();
//			DefaultListModel dlm = playlistMakerPanel.playlistListModel;
//			int size = dlm.getSize();
//			int index = jl.getSelectedIndex();
//			if (!e.getValueIsAdjusting() && playlist.getSongs().size() > 0
//					&& jl.getSelectedIndex() > -1) {
//				if (testing)
//					System.out.print("Playlist event, selected index: " + index);
//
//				// remove song from playlist and jlist - right now only
//				// removes when you add another song
//				try {
//					
//					// remove song from playlist
//					playlist.deleteSong(((JList) e.getSource()).getSelectedIndex());
//					((JList) e.getSource()).clearSelection();
//
//					//dlm.remove(index);
//					
////					playlistMakerTab.remove(playlistMakerPanel);
////					playlist.deleteSong(index);
////
////					playlistMakerPanel = new PlaylistMakerPanel(playlist);
////					playlistMakerTab.add(playlistMakerPanel);
//					
//	                if (index == dlm.getSize()) {
//	                    //removed item in last position
//	                    index--;
//	                }
//	                //jl.setSelectedIndex(index);
//	                jl.ensureIndexIsVisible(index);
//	                //System.out.println("ignore repaint? "+jl.getIgnoreRepaint());
//	                
////					playlistMakerPanel.playlistList.clearSelection();
//					// update GUI to reflect changes
//					// playlistMakerPanel.playlistList.removeAll();
//					// playlistMakerPanel.playlistList = new
//					// JList(playlistMakerPanel.playlistListModel);
////					setVisible(true);
////					playlistMakerPanel.getList().revalidate();
////					playlistMakerPanel.getList().repaint();
//					System.out.println("playlistListModel size: " + dlm.getSize());
//				} catch (ArrayIndexOutOfBoundsException excep) {
//				}
//
//				// return song to oldSongsList if it was from OldSongs
//				// if (oldSongs.contains(current)) {
//				// // Song song = ((Song)
//				// System.out.println(songInputPanel.getOldSongsList()
//				// .getComponents());
//				// int index1 = oldSongs.getIndexOf(current);
//				// playlistMakerPanel.playlistListModel
//
//				playlistMakerPanel.playlistPane.
//				revalidate();
//				playlistMakerPanel.playlistPane.
//				repaint();
//			} // end getValueIsAdjusting
//		} // end valueChanged
//	}// end PlaylistSelectionListener
}
