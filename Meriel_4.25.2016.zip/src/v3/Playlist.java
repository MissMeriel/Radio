package v3;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;

public class Playlist {

	private String playlistName;

	private int playlistCount = 0;
	public static final Duration TIME_REMAINING_EPSILON = Duration
			.ofSeconds(150l);
	private Duration currentLength = Duration.ofSeconds(0l);
	static final int SONG_NOT_ADDED = Integer.MIN_VALUE;
	static final int SONG_NOT_FOUND = Integer.MIN_VALUE;
	final int REPORT_INTERVAL = 0;
	// Is this measured in milliseconds/seconds/minutes etc?
	public static final Duration MAX_TIME = Duration.ofSeconds(4 * 3600l);
	private ArrayList<Broadcastable> playlist = new ArrayList<Broadcastable>();
	// could have a getLastAd that returns last time an ad was added
	private int promotionTime = 1800;
	private int reportTime = 3600;
	Reader adRdr = new Reader();
	Reader spotRdr = new Reader();
	Reader newsRdr = new Reader();
	Reader trafficRdr = new Reader();
	ArrayList<Commercial> adList;
	ArrayList<Report> trafficReportList;
	ArrayList<Report> newsReportList;
	ArrayList<RadioSpot> radioSpotList;
	Random rand = new Random();

	/**
	 * Constructor for playlist
	 * 
	 * @param playlistName
	 */
	public Playlist(String playlistName) {
		this.playlistName = playlistName;
		playlistCount++;
		playlist = new ArrayList<Broadcastable>();
		try {
			adRdr = new Reader("src/AdList.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		adList = adRdr.getCommercials();
		try {
			spotRdr = new Reader("src/RadioSpotList.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		radioSpotList = spotRdr.getSpots();
		try {
			newsRdr = new Reader("src/NewsReportList.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		newsReportList = newsRdr.getReports(false);
		try {
			trafficRdr = new Reader("src/TrafficReportList.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		trafficReportList = trafficRdr.getReports(true);
	}

	/**
	 * Adds song to the end of playlist ArrayList
	 * 
	 * @param s
	 * @return int corresponding to the added song's index in the ArrayList if
	 *         it was added, or Interger.MIN_VALUE if it was not added
	 * @throws OverTimeException
	 * @throws ParseException
	 */
	public int addItem(Broadcastable s) throws OverTimeException,
			ParseException {
		int i = 0;
		while (playlist.contains(i)) {
			i++;
		}
		if (playlist.add(s)) {
			// Forgot to set your length, also...
			// currentLength.plus(Duration d) RETURNS a COPY; Need to set it
			// permanently!(See setplaylist()).
			currentLength = currentLength.plus(s.getLength());
			// return i;
			if (currentLength.getSeconds() >= promotionTime && currentLength.getSeconds() < 3300l) {
				promotionTime += 1800;
				for(int j = 0; j < 8; j++){
					addItem(adList.get(rand.nextInt(adList.size())));
				}
				for(int k = 0; k < 2; k++){
					addItem(radioSpotList.get(rand.nextInt(radioSpotList.size())));
				}
			}
			if (currentLength.getSeconds() >= reportTime && currentLength.getSeconds() < 3300l) {
				reportTime += 3600;
				NewsReport nr = (NewsReport) newsReportList.get(rand.nextInt(newsReportList.size()));
				addItem(nr);
				currentLength = currentLength.plus(NewsReport.NEWS_REPORT_LENGTH);
				TrafficReport tr = (TrafficReport) trafficReportList.get(rand.nextInt(trafficReportList.size())); 
				addItem(tr);
				currentLength = currentLength.plus(TrafficReport.TRAFFIC_REPORT_LENGTH);
			}
			return i;
		} else
			return SONG_NOT_ADDED;
	}

	/**
	 * @return ArrayList<Song> ArrayList of playlist in the playlist
	 */
	public ArrayList<Broadcastable> getItems() {
		return playlist;
	}

	/**
	 * set Playlist's playlist ArrayList to the ArrayList parameter
	 * 
	 * @param playlist
	 * @throws Exception
	 */
	public void setPlaylist(ArrayList<Broadcastable> playlist)
			throws OverTimeException {
		for (Broadcastable item : playlist) {
			currentLength.plus(item.getLength());
			if (currentLength.compareTo(MAX_TIME) > 0) {
				this.playlist = null;
				throw new OverTimeException();
			}
		}
		this.playlist = playlist;
	}

	/**
	 * Delete all copies of this song in the ArrayList
	 * 
	 * @param song
	 */
	public void deleteSong(Song song) {
		Iterator<Broadcastable> iter = playlist.iterator();
		while (iter.hasNext()) {
			Broadcastable current = iter.next();
			if (song.equals(current))
				playlist.remove(current);
		}
	} // end deleteSong()

	/**
	 * Remove song by its index in the ArrayList
	 * 
	 * @param index
	 */
	public void deleteSong(int index) {
		System.out.println("deleteSong index: " + index);
		// Need to set our currentLength
		currentLength = currentLength.minus(playlist.get(index).getLength());
		playlist.remove(index);
	}
	
	private ArrayList<Broadcastable> adjustAdsAndReports(){
		Iterator<Broadcastable> iter = playlist.iterator();
		while (iter.hasNext()){
			Broadcastable b = iter.next();
			if (b instanceof Report || b instanceof Promotion){
				iter.remove();
				currentLength = currentLength.minus(b.getLength());
			}
		}
		ArrayList<Broadcastable> al = new ArrayList<Broadcastable>();
		al.addAll(playlist);
		int promoTime = 1800;
		int repTime = 3600;
		Duration alLength = Duration.ofSeconds(0);
		for (Broadcastable b : al){
			alLength = alLength.plus(b.length);
			if(alLength.getSeconds() >= promoTime && alLength.getSeconds() < 3300l){
				for(int j = 0; j < 8; j++){
					al.add(adList.get(rand.nextInt(adList.size())));
				}
				for(int k = 0; k < 2; k++){
					al.add(radioSpotList.get(rand.nextInt(radioSpotList.size())));
				}
			}
		}
		return al;
	}

	public String getPlaylistName() {
		return playlistName;
	}

	public void setPlaylistName(String playlistName) {
		this.playlistName = playlistName;
	}

	public Broadcastable getItem(int index) {
		return playlist.get(index);
	}

	/**
	 * 
	 * @return Duration object of MAX_TIME minus current length
	 * @throws OverTimeException
	 */
	public Duration timeLeft() throws OverTimeException {
		// Here's why Old playlist weren't working:
		// Need to be "<" 0, not ">".
		// currentLength needs to be LESS THAN max time.
		if (currentLength.compareTo(MAX_TIME) < 0)
			return MAX_TIME.minus(currentLength);
		else
			throw new OverTimeException();
	}

	/**
	 * Return a "DJ Signoff" radiospot with the remaining amount of time if the 
	 * remaining amount of time is <= MAX_TIME.minus(TIME_REMAINING_EPSILON)
	 * @throws OverTimeException 
	 */
	// checking whether the amount of time remaining is small
	// enough to warrant this method before method call in
	// the GUI
	public RadioSpot fillRemainingtime() throws OverTimeException{
		if(timeLeft().compareTo(MAX_TIME.minus(TIME_REMAINING_EPSILON)) <= 0){
			return new RadioSpot("End of Set: DJ Signoff",
					MAX_TIME.minus(currentLength));
		}
		return null;
	}

	/**
	 * Returns index of song if it is in playlist; if not, returns
	 * Integer.MIN_VALUE
	 */
	public int search(String song) {
		for (int i = 0; i < playlist.size(); i++) {
			if (playlist.get(i) instanceof Song) {
				if (((Song) playlist.get(i)).getTitle().contains(song))
					return (i + 1);
			}
		}
		return SONG_NOT_FOUND;
	}

	@Override
	public String toString() {
		String str = playlistName;
		for (int i = 0; i < playlist.size(); i++) {
			if (playlist.get(i) != null) {
				str += ((i + 1) + ". " + playlist.get(i));
			}
		}
		return str;
	} // end printPlaylist method

	public boolean find(Song song) {
		if (song == null)
			return false;
		for (int i = 0; i < playlist.size(); i++) {
			if (playlist.get(i).toString().contains(song.toString())) {
				return (true);
			}
		}
		return false;
	}

	/**
	 * 
	 * @return a String representation of the remaining time in "0:00:00" format
	 * @throws OverTimeException
	 */
	public String timeRemaining() throws OverTimeException {
		String str = "Time Remaining: ";
		Duration tr = timeLeft();
		long hrs = tr.toHours();
		str += tr.toHours() + ":";
		long min = tr.minusHours(tr.toHours()).toMinutes();
		if (min < 10)
			str += 0;
		str += min + ":";
		long sec = tr.minusHours(hrs).minusMinutes(min).getSeconds();
		if (sec < 10)
			str += 0;
		str += sec;
		return str;
	}

	public Duration getLength() {
		return currentLength;
	}

} // end Playlist class
