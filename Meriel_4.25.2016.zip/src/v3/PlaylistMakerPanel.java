package v3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PlaylistMakerPanel extends JPanel {

	JLabel playlistTitle = new JLabel("");;
	JButton playlistTitleEdit = new JButton("Enter");
	JTextField playlistTitler = new JTextField("Your Playlist Title");
	JLabel timeRemaining = new JLabel("Time Remaining: 4:00:00");
	JPanel topPanel = new JPanel(new GridLayout(2, 1));
	JPanel mid, midPanel, bot, botPanel;
	public DefaultListModel playlistListModel;
	public JList playlistList = new JList();
	public JScrollPane playlistPane;
	public Playlist playlist;
	boolean testing = true;
	JButton finalizeButton;
	JButton rdsButton;
	MarqueePanel mp;

	public PlaylistMakerPanel(Playlist playlist, MarqueePanel mP,
			FinalizedPlaylistPanel finalizedPanel) {
		this.playlist = playlist;
		this.mp = mP;
		setLayout(new BorderLayout());

		makeTitlePanel();

		playlistListModel = new DefaultListModel();
		if (playlist.getItems().size() > 0) {
			for (Broadcastable item : playlist.getItems()) {
				playlistListModel.addElement(item);

			}
		}
		playlistList = new JList(playlistListModel);
		playlistList.setVisibleRowCount(15);
		playlistList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		playlistList.setCellRenderer(new PlaylistCellRenderer());
		playlistPane = new JScrollPane(playlistList);
		playlistPane.setOpaque(true);
		playlistPane.setPreferredSize(new Dimension(250, 400));

		// mid panel displays the playlist we're working on.
		mid = new JPanel();
		mid.add(playlistPane);

		// rds button & listener
		rdsButton = new JButton("View in RDS");
		rdsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("inside actionlistener for View in RDS");
				mP.setMarqueeText(playlist.getItems().get(0).toString());
			}
		});
		finalizeButton = new JButton("Finalize");

		// finalize button & listener -- finish actionlistener for Finalize
		// button
		// adds playlist to finalizedPlaylistsTab if its length is sufficient
		finalizeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (playlist.timeLeft().getSeconds() < Playlist.TIME_REMAINING_EPSILON
							.getSeconds()) {
						finalizedPanel.addFinalizedPanel(playlist);
						
					} else {
						JOptionPane.showMessageDialog(null,
							    "Your playlist must be at least 3:58:30",
							    "Warning: Under Time",
							    JOptionPane.WARNING_MESSAGE);
					}
				} catch (OverTimeException e1) {
					// TODO Auto-generated catch block
					// e1.printStackTrace();
				}
			}
		});
		bot = new JPanel();
		bot.add(rdsButton);
		bot.add(finalizeButton);

		// Add the panels to their respective places.
		add(topPanel, BorderLayout.NORTH);
		add(mid, BorderLayout.CENTER);
		add(bot, BorderLayout.SOUTH);
	}

	public void updateTimeRemaining(String str) {
		timeRemaining.setText(str);
	}

	public JList getList() {
		return playlistList;
	}

	private void makeTitlePanel() {

		// top holds playlist title and timeRemaining
		JPanel top = new JPanel();

		// grid layout of 2 rows and 1 column
		top.setLayout(new GridLayout(1, 2));

		playlistTitler.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {
				playlistTitler.setText("");
			}

			@Override
			public void focusLost(FocusEvent e) {
				if (playlistTitler.getText().equals("")) {
					playlistTitler.setText("Your Playlist Title");
				}
			}
		});

		// when edit/enter button clicked, playlist title is entered/edited
		playlistTitleEdit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// if the title is editable
				if (playlistTitleEdit.getText().equals("Enter")) {
					playlistTitle.setText(playlistTitler.getText());
					playlistTitleEdit.setText("Edit");
					// top.remove(playlistTitler);
					top.removeAll();
					top.add(playlistTitle);
					top.add(playlistTitleEdit);
					playlist.setPlaylistName(playlistTitle.getText());

					// if the user wants to edit the title
				} else {
					top.removeAll();
					top.add(playlistTitler);
					playlistTitleEdit.setText("Enter");
					top.add(playlistTitleEdit);
				}

			}
		});
		top.add(playlistTitler);
		top.add(playlistTitleEdit);
		// playlistTitleEdit.setAlignmentY(RIGHT_ALIGNMENT);
		topPanel.add(top);
		topPanel.add(timeRemaining);
	}

	private class PlaylistCellRenderer extends DefaultListCellRenderer {
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			Component comp = super.getListCellRendererComponent(list, value,
					index, false, false);

			if (isSelected && cellHasFocus) {

				comp.setForeground(Color.gray);
				comp.setEnabled(false);
			}
			return comp;
		}
	} // end PlaylistCellRendererComponent

} // end PlaylistMakerPanel

